"""Job source collectors."""
