"""International Job Hunter pipeline."""
